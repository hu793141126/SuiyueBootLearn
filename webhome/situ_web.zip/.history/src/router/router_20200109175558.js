import i18n from '@/assets/js/lang/i18n';
/*
* meta中属性的作用:
* title：当前页面不需要侧边栏时顶部栏的标题。类型为 String/Function
* backUrlName：点击返回的时候，目标路由的name
* backQuery：点击返回的时候，目标路由的query
* backFn：点击返回的时候，执行的回调，参数是当前vue实例
* */


// handleBackFn 方法用于获取保存在 sessionStorage 中的路由query并跳转路由。暂时没用 2019-12-25
// const handleBackFn = (vm, name) => {
//     let query = sessionStorage.backRouterQuery || '{}';
//     vm.$router.push({
//         name: name,
//         query: JSON.parse(query)
//     });
// };

const sysAdmin = [
    // 部署管理
    {
        path: '/deploy-manage',
        name: 'deploy-manage',
        component: () => import('@/views/sys-admin/deploy-manage/deploy-manage.vue')
    },
    // 系统管理-系统日志
    {
        path: '/system-log',
        name: 'system-log',
        component: () => import('@/views/sys-admin/sys-manage/system-log.vue')
    },
    // 系统管理-系统告警
    {
        path: '/sys-alert',
        name: 'sys-alert',
        component: () => import('@/views/sys-admin/sys-manage/sys-alert.vue')
    },
    // 系统管理-系统升级
    {
        path: '/sys-upgrade',
        name: 'sys-upgrade',
        component: () => import('@/views/sys-admin/sys-manage/sys-upgrade.vue')
    },
    // 系统管理-系统安全
    {
        path: '/sys-security',
        name: 'sys-security',
        component: () => import('@/views/sys-admin/sys-manage/sys-security.vue')
    },
    // 系统管理-系统诊断
    {
        path: '/sys-diagnosis',
        name: 'sys-diagnosis',
        component: () => import('@/views/sys-admin/sys-manage/sys-diagnosis.vue')
    },
    // 系统管理-通信设置
    {
        path: '/internet-server',
        name: 'internet-server',
        component: () => import('@/views/sys-admin/sys-manage/internet-server.vue')
    },
    // 系统管理-系统时间
    {
        path: '/sys-time',
        name: 'sys-time',
        component: () => import('@/views/sys-admin/sys-manage/sys-time.vue')
    },
    // 设备管理
    {
        path: '/device-manage',
        name: 'device-manage',
        component: () => import('@/views/sys-admin/device-manage/device-manage.vue')
    },
    // 数据维护
    {
        path: '/data-maintain',
        name: 'data-maintain',
        component: () => import('@/views/sys-admin/data-maintain/data-maintain.vue')
    },
    // 许可证
    {
        path: '/license',
        name: 'license',
        component: () => import('@/views/sys-admin/license/license.vue')
    },
];
const secAdmin = [
    // 态势概览
    {
        path: '/situation-overview',
        name: 'situation-overview',
        component: () => import('@/views/sec-admin/situation-overview/situation-overview.vue'),
        meta: {
            query: {
                active: 'overallSituation',
            }
        }
    },
    // 治理工作台-一键巡检资产
    {
        path: '/retrieve-assets',
        name: 'retrieve-assets',
        component: () => import('@/views/sec-admin/govern-platform/retrieve-assets.vue')
    },
    // 治理工作台-数据一览
    {
        path: '/data-browse',
        name: 'data-browse',
        component: () => import('@/views/sec-admin/govern-platform/data-browse/data-browse.vue'),
        meta: {
            query: {
                active: 'secModelView',
            }
        }
    },
    // 治理工作台-数据一览，原数据检索，详情
    {
        path: '/data-search-detail',
        name: 'data-search-detail',
        component: () => import('@/views/sec-admin/govern-platform/data-browse/components/data-search-detail.vue'),
        meta: {
            title: i18n.t('DataSearch.detailTitle'),
            backUrlName: 'data-browse',
            backQuery: {
                active: 'dataSearch',
            },
        }
    },
    // 治理工作台-态势评估与预测
    {
        path: '/situation-predict',
        name: 'situation-predict',
        component: () => import('@/views/sec-admin/govern-platform/situation-predict/situation-predict.vue'),
        meta: {
            query: {
                active: 'situAssess',
            }
        }
    },
    // 治理工作台-数据流动梳理
    {
        path: '/data-flow',
        name: 'data-flow',
        component: () => import('@/views/sec-admin/govern-platform/data-flow.vue')
    },
    // 治理工作台-数据资产管理
    {
        path: '/data-assets',
        name: 'data-assets',
        component: () => import('@/views/sec-admin/govern-platform/data-assets/data-assets.vue'),
        meta: {
            query: {
                active: 'assetsOverview'
            }
        }
    },
    // 治理工作台-数据资产管理-资产管理-资产详情
    {
        path: '/assets-detail',
        name: 'assets-detail',
        component: () => import('@/views/sec-admin/govern-platform/data-assets/components/assets-detail.vue'),
        meta: {
            title: i18n.t('AssetsManage.assetsDetail.assetsDetail'),
            backUrlName: 'data-assets',
            backFn: vm => {
                vm.$akRoute.savePush(vm, {
                    name: 'data-assets'
                });
            },
        }
    },
    // 治理工作台-数据资产管理-资产发现-敏感任务编辑
    {
        path: '/sensitive-task-edit',
        name: 'sensitive-task-edit',
        component: () => import('@/views/sec-admin/govern-platform/data-assets/components/sensitive-task-edit.vue'),
        meta: {
            title: vm => {
                return vm.$route.query.type === 'add' ? i18n.t('SensitiveTask.edit.addTitle') : i18n.t('SensitiveTask.edit.modifyTitle');
            },
            backUrlName: 'data-assets',
            backQuery: {
                active: 'assetsDiscovery',
                activeDiscovery: 'sensitiveTask'
            },
            // backFn: vm => {
            //     handleBackFn(vm, 'data-assets');
            // },
        }
    },
    // 治理工作台-数据资产管理-资产发现-敏感任务结果
    {
        path: '/sensitive-task-result',
        name: 'sensitive-task-result',
        component: () => import('@/views/sec-admin/govern-platform/data-assets/components/sensitive-task-result.vue'),
        meta: {
            title: i18n.t('SensitiveTask.result.title'),
            backUrlName: 'data-assets',
            backQuery: {
                active: 'assetsDiscovery',
                activeDiscovery: 'sensitiveTask'
            },
        }
    },
    // 治理工作台-数据资产管理-资产发现-敏感类型
    {
        path: '/sensitive-type',
        name: 'sensitive-type',
        component: () => import('@/views/sec-admin/govern-platform/data-assets/components/sensitive-type.vue'),
        meta: {
            title: i18n.t('SensitiveType.common.title'),
            backUrlName: 'data-assets',
            backQuery: {
                active: 'assetsDiscovery',
                activeDiscovery: 'sensitiveTask'
            },
        }
    },
    // 治理工作台-数据资产管理-资产发现-敏感类型-敏感类型编辑
    {
        path: '/sensitive-type-edit',
        name: 'sensitive-type-edit',
        component: () => import('@/views/sec-admin/govern-platform/data-assets/components/sensitive-type-edit.vue'),
        meta: {
            title: i18n.t('SensitiveType.edit.title'),
            backUrlName: 'sensitive-type',
            // backFn: vm => {
            //     vm.$router.back(-1);
            // }
        }
    },
    // 治理工作台-数据资产管理-资产发现-数据字典
    {
        path: '/data-dictionary',
        name: 'data-dictionary',
        component: () => import('@/views/sec-admin/govern-platform/data-assets/components/data-dictionary.vue'),
        meta: {
            title: i18n.t('ModuleList.dataDictionary'),
            backUrlName: 'data-assets',
            backQuery: {
                active: 'assetsDiscovery',
                activeDiscovery: 'sensitiveTask'
            },
        }
    },
    // 治理工作台-拓扑管理
    {
        path: '/topology-manage',
        name: 'topology-manage',
        component: () => import('@/views/sec-admin/govern-platform/topology-manage'),
    },
    // 风险管理-风险概览
    {
        path: '/risk-overview',
        name: 'risk-overview',
        component: () => import('@/views/sec-admin/risk-manage/risk-overview/risk-overview.vue'),
        meta: {
            query: {
                active: 'overallRisk',
            }
        }
    },
    // 风险管理-风险处理
    {
        path: '/risk-treatment',
        name: 'risk-treatment',
        component: () => import('@/views/sec-admin/risk-manage/risk-treatment.vue'),
    },
    // 报表管理-内置报表
    {
        path: '/attribute-report',
        name: 'attribute-report',
        component: () => import('@/views/sec-admin/report-manage/attribute-report.vue')
    },
    // 报表管理-等保报表
    {
        path: '/grade-protect-report',
        name: 'grade-protect-report',
        component: () => import('@/views/sec-admin/report-manage/grade-protect-report.vue')
    },
    // 报表管理-工作台
    {
        path: '/workbench',
        name: 'workbench',
        component: () => import('@/views/sec-admin/report-manage/workbench.vue')
    },
    // 能力单元管理
    {
        path: '/ability-unit',
        name: 'ability-unit',
        component: () => import('@/views/sec-admin/ability-unit/ability-unit.vue')
    },
    // 能力单元管理-编辑
    {
        path: '/ability-unit-edit',
        name: 'ability-unit-edit',
        component: () => import('@/views/sec-admin/ability-unit/components/ability-unit-edit.vue'),
        meta: {
            title: i18n.t('AbilityUnit.edit.title'),
            backUrlName: 'ability-unit',
        }
    },
    // 安全模型-安全规则配置
    {
        path: '/sec-mode',
        name: 'sec-mode',
        component: () => import('@/views/sec-admin/config-manage/sec-mode.vue'),
        meta: {
            query: {
                active: 'rule',
            }
        }
    },
    // 配置管理-解析规则
    {
        path: '/parsing-rule',
        name: 'parsing-rule',
        component: () => import('@/views/sec-admin/config-manage/parsing-rule.vue')
    },
    // 配置管理-分析任务
    {
        path: '/analysis-task',
        name: 'analysis-task',
        component: () => import('@/views/sec-admin/config-manage/analysis-task.vue')
    },
    // 配置管理-联动配置
    {
        path: '/linkage',
        name: 'linkage',
        component: () => import('@/views/sec-admin/config-manage/linkage.vue')
    },
    // 配置管理-威胁库
    {
        path: '/threat',
        name: 'threat',
        component: () => import('@/views/sec-admin/config-manage/threat.vue')
    },
    // 配置管理-告警策略
    {
        path: '/alarm-strategy',
        name: 'alarm-strategy',
        component: () => import('@/views/sec-admin/config-manage/alarm-strategy.vue')
    },
    // 配置管理-组织架构
    {
        path: '/org-structure',
        name: 'org-structure',
        component: () => import('@/views/sec-admin/config-manage/org-structure.vue')
    },
    // 配置管理-责任人
    {
        path: '/duty-person',
        name: 'duty-person',
        component: () => import('@/views/sec-admin/config-manage/duty-person.vue')
    },

];
const auditAdmin = [
    {
        path: '/operation-log',
        name: 'operation-log',
        component: () => import('@/views/audit-admin/operation-log.vue')
    },
];

const userSetting = [
    // 用户管理
    {
        path: '/user-manage',
        name: 'user-manage',
        component: () => import('@/views/user-setting/user-manage.vue'),
        meta: {
            title: i18n.t('UserSetting.userManage.userManage'),
            backFn: vm => {
                let preUrl = vm.$route.query.preUrl || 'home';
                vm.$router.push({ name: preUrl });
            },
        }
    },
    // 用户管理-编辑用户
    {
        path: '/user-manage-edit',
        name: 'user-manage-edit',
        component: () => import('@/views/user-setting/user-manage-edit.vue'),
        meta: {
            title: vm => {
                return vm.$route.query.type === 'add' ? i18n.t('UserSetting.userManage.addUser') : i18n.t('UserSetting.userManage.modifyUser');
            },
            backUrlName: 'user-manage',
        }
    },
    // 用户管理-用户详情
    {
        path: '/user-manage-detail',
        name: 'user-manage-detail',
        component: () => import('@/views/user-setting/user-manage-detail.vue'),
        meta: {
            title: i18n.t('UserSetting.userManage.userDetail'),
            backUrlName: 'user-manage',
        }
    },
    // 修改密码
    {
        path: '/user-password',
        name: 'user-password',
        component: () => import('@/views/user-setting/user-password.vue'),
        meta: {
            title: i18n.t('UserSetting.modifyPassword.modifyPassword'),
            backFn: vm => {
                // 管理员密码过期之后，点击返回去到登录页
                if (sessionStorage.pwdStatus === '2') {
                    sessionStorage.removeItem('token');
                    window.location.reload();
                } else {
                    vm.$router.go(-1);
                }
            },
        }
    },
    // 用户信息
    {
        path: '/user-info',
        name: 'user-info',
        component: () => import('@/views/user-setting/user-info.vue'),
        meta: {
            title: i18n.t('UserSetting.userInfo.userInfo'),
            backFn: vm => {
                vm.$router.go(-1);
            },
        }
    },
    {
        path: '/sys-lock',
        name: 'sys-lock',
        component: () => import('@/views/user-setting/sys-lock.vue'),
        meta: {
            title: i18n.t('UserSetting.sysLock.sysLock'),
            backUrlName: '',
        }
    },
];
const route = [
    // 下面这个路由用于测试主题换肤，以后会删除
    {
        path: '/theme-demo',
        name: 'theme-demo',
        component: resolve => {
            require(['@/views/theme-demo.vue'], resolve);
        }
    },
    {
        path: '/login',
        name: 'login',
        component: resolve => {
            require(['@/views/login.vue'], resolve);
        }
    },
    {
        path: '/',
        name: 'home',
        component: resolve => {
            require(['@/views/home.vue'], resolve);
        },
        children: sysAdmin.concat(secAdmin, auditAdmin, userSetting)
    }
];
export default route;
