import Vue from 'vue';
import axios from 'axios';
import Qs from 'qs';
import store from '@/store/store'; // vuex
import i18n from '@/assets/js/lang/i18n.js';
import fileDownload from 'js-file-download';
import router from '@/router/index';

axios.defaults.headers.common['Pragma'] = 'no-cache'; // Pragma 用于向后兼容HTTP/1.1缓存，其中Cache-Control HTTP/1.1头尚不存在
axios.defaults.headers.common['Cache-Control'] = 'no-cache'; // 缓存控制：不缓存
// 开发环境下需要有api段,用于进行反向代理的切换; 生产环境下需要切换端口号,适用于前后端分离情况下(前后台包部署在不同端口号中)
const prodBaseURL = location.protocol + '//' + location.hostname + (location.protocol === 'http:' ? ':8080' : ':8443');
axios.defaults.baseURL = process.env.NODE_ENV === 'development' ? '/api/' : prodBaseURL;

// 添加请求拦截器
axios.interceptors.request.use(config => {
    store.state.pending = false;
    config.headers['authorization'] = sessionStorage.token; // 让每个请求携带token-- ['X-Token']为自定义key 请根据实际情况自行修改
    return config;
}, error => {
    Promise.reject(error);
});

// 响应拦截,主要是根据后端返回的 message 或者 http状态码 显示提示信息
axios.interceptors.response.use(
    res => {
        showMsg('success', res.data);
        store.state.pending = true;
        return res;
    },
    error => {
        let codeNumber = error.toString().split(' ').pop();
        // 如果返回以下状态码，需要重新登录
        let reLoginCodes = ['403', '408', '502', '504', '3006'];
        if (codeNumber === '401') {
            // 如果用户未授权'401'，直接去到登录页
            sessionStorage.token = '';
            router.replace({ name: 'login' });
            return;
        }
        if (reLoginCodes.includes(codeNumber)) {
            store.commit('showAlert', {
                content: i18n.t(`HttpCode.http${codeNumber}`),
                okFn: () => {
                    sessionStorage.token = '';
                    router.replace({ name: 'login' });
                }
            });
            return;
        }

        showMsg('fail', `http${codeNumber}`);
        return {
            data: {
                code: -1
            }
        };
    }
);

axios.defaults.transformRequest = [function (data, headers) {
    // 如果没有额外设置请求头的时候,直接返回一个用&连接的序列化结果
    if (!headers['Content-Type']) return Qs.stringify(data);
    switch (headers['Content-Type'].toLowerCase()) {
        // 返回得到一个对象(可以为json或者是一个数组)
        case 'application/json;charset=utf-8': {
            return JSON.stringify(data);
        }
        // 如果当前发送的是formData属性的配置时,直接将当前的data返回,不做任何的处理(默认当前请求头的内容为formData格式)
        case 'multipart/form-data;charset=utf-8': {
            return data;
        }
        // 默认返回Qs序列化后的内容,防止内容没有进行处理
        default: {
            return Qs.stringify(data);
        }
    }
}];

// 根据后端返回的 message 或者 http状态码 显示提示信息
function showMsg(result, data) {
    if (result === 'success') {
        // 请求成功
        if (data.code !== 0 && data.message) {
            store.commit('showAlert', { content: data.message });
        }
    } else {
        // 请求报错
        let obj = i18n.t('HttpCode');
        Object.keys(obj).includes(data) && store.commit('showAlert', { content: obj[data] });
    }
}


/*
* 通过用户传入的method方法, query参数来决定要发送请求时候需要装载的配置内容
* 1.get请求下不要发送引用类型数据,包括数组,value中存在对象,文件等(原因是目前后台还没有办法获取到传过去的数据)
* 2.发送文件类型的时候一般不手动添加'multipart/form-data;charset=UTF-8'这个请求头,必须由浏览器添加.但是axios源码中有删除这个请求头的操作不用担心.
* 3.如果发送文件时候还需要发送其他属性的数据,则需要通过FormData来进行构造数据(目前还没有测试过,测试过之后删除这个提示)
* 4.下载文件(通过blob对象),需要在userOption配置中加上responseType: 'blob'内容,并且因为后台不能返回特定的格式,所以需要传入error函数进行下载
* 5.发送数组的时候需要确认后台是需要直接发送一个数组过去(一般会采取这种形式),还是需要在数组前面加一个key值
* 6.默认一次请求中只存在params参数,或者只存在data参数
*
* @params {object} require {
*   method // 方法(get, post, put, delete)
*   url // 请求地址url
*   query // 非必填--需要发送给后台的参数(params或者data参数)
*   success (res) => {}, // 非必填--请求成功后执行的函数
*   error (res) => {}, // 非必填--请求失败后(要额外)执行的函数
*   userOption // 非必填--用户配置(当前默认配置不满足该请求时,可以设置额外的配置项进行替换或者添加)
* }
* */
async function requestFn(require) {
    // 是否有引用类型数据
    let hadReferenceType = false;
    // 是否有文件类型数据
    let hadFileType = false;
    // 定义获取类型的方法
    let toString = Object.prototype.toString;
    // 当前请求的请求头信息
    let headers = {};
    // 请求的所有配置
    let adaptOption = {};
    // 响应的内容
    let response = {};

    // 如果后台能够接收get请求下的引用类型数据,则可以将这里的判断去除
    if (require.method === 'get' && require.query && (toString.call(require.query) === '[object Array]')) {
        console.error('在get请求下,后台还不知道接收复杂类型数据的方法');
    }

    // 判断当前传进来的参数中是否存在文件类型数据或者引用类型数据
    (toString.call(require.query) === '[object Array]') && (hadReferenceType = true);
    if (toString.call(require.query) === '[object Object]') {
        Object.keys(require.query).forEach(item => {
            switch (toString.call(require.query[item])) {
                case '[object Object]':
                case '[object Array]': {
                    hadReferenceType = true;
                    break;
                }
                case '[object File]': {
                    hadFileType = true;
                    break;
                }
                default: { break }
            }
        });
    }

    // 为不同的数据类型适配不同的请求头: 1.有文件数据; 2.有引用类型数据(分为数组或者是对象); 3. 其他的key: value形式的数据
    headers = hadFileType ? { 'Content-Type': 'multipart/form-data;charset=UTF-8' } :
        hadReferenceType ? { 'Content-Type': 'application/json;charset=UTF-8' } :
        { 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8' };

    // 装载发送请求时的配置
    adaptOption = {
        method: require.method,
        url: require.url,
        headers,
        data: require.method !== 'get' ? require.query : null,
        params: require.method !== 'get' ? null : require.query
    };

    // 可以使用自定义的内容进行替换上面配置出来的adaptOption,或者adaptOption中不存在属性时会自动添加
    if (require.userOption) {
        Object.keys(require.userOption).forEach(key => {
            if (Object.keys(adaptOption).includes(key)) {
                Object.assign(adaptOption[key], require.userOption[key]);
            }
            else {
                adaptOption[key] = require.userOption[key];
            }
        });
    }

    // 通过async和await来进行异步控制请求的发送
    response = await axios(adaptOption);

    // 如果后台返回的是个文件流，则axios的response.data里面的将会是Blob对象的实例，之后就可以下载文件，如果返回的不是文件流则说明是一般对象，就可以判断其中的code码
    if (response.data instanceof Blob) {
        let disposition = response.headers['content-disposition'];
        if (!disposition) {
            store.commit('showAlert', { content: i18n.t('Common.axios.downloadError') });
            return false;
        }
        let fileName = decodeURI(disposition.split('filename=')[1]);
        fileDownload(response.data, fileName);

        // 执行成功函数
        require.success && require.success(response.data.data, response);
    } else {
        // 根据后端返回的状态码进行判断执行成功函数或者失败函数,注意两个函数返回数据的层级不一样,并且都可利用第二个参数来获取整个请求的内容
        response.data.code === 0 ?
            (require.success && require.success(response.data.data, response)) :
            (require.error && require.error(response.data, response));
    }
}

/*
* 注意method,url都是必填项,其他项都是非必填项.
* 请求成功和请求失败的情况下返回的数据层级不一致,为满足特殊需求,会传返回第二个参数(整个请求响应的内容). 编写成功或者错误函数的时候可以不加函数参数
* 注意下载文件时(后端不能按照 '{ code: 0, data: {} }' 格式返回),所以请求成功后,必须将下载操作放到error函数中,并从返回的第二个参数获取内容
* */
Vue.prototype.$http = {
    /*
    * 使用原生ajax获取换肤的样式文件。
    * 不使用axios是因为 在开发环境下会默认加上 /api/ 前缀，导致反向代理到了开发环境设备，从而获取不到本地静态资源
    */
    getThemeFile() {
        return new Promise(resolve => {
            const url = location.origin + '/static/styles/theme.css';
            const xhr = new XMLHttpRequest();
            xhr.onreadystatechange = () => {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    resolve(xhr.responseText);
                }
            };
            xhr.open('GET', url);
            xhr.send();
        });
    },

    // 登录模块：登录
    login(query, success, error) {
        requestFn({ method: 'post', url: '/login/user-login', query, success, error });
    },
    // 登录模块：退出登录
    logout(success, error) {
        requestFn({ method: 'post', url: '/login/user-logout', success, error });
    },
    // 登录模块: 获取验证码
    getCheckCode(query, success) {
        requestFn({ method: 'get', url: '/login/check-code', query, success });
    },
    // 登录模块: 获取手机验证码
    getPhoneCode(query, success) {
        // requestFn({ method: 'get', url: '/login/check-code', query, success });
    },


    /* -------数据一览-------start */
    // 安全事件检索：查询安全事件
    getSearchEvent(query, success, error) {
        requestFn({ method: 'get', url: '/event-retrieval/query-info', query, success, error });
    },
    // 原数据检索：获取日志类型
    getSearchLogType(query, success, error) {
        requestFn({ method: 'get', url: '/data-retrieval/log-type', query, success, error });
    },
    // 原数据检索：获取日志类型对应的能力单元
    getSearchAbilityUnit(query, success, error) {
        requestFn({ method: 'get', url: '/data-retrieval/safety-devices', query, success, error });
    },
    // 原数据检索：获取操作类型下拉框
    getSearchOperType(query, success, error) {
        requestFn({ method: 'get', url: '/data-retrieval/oper-type', query, success, error });
    },
    // 原数据检索：查询审计日志
    getAuditLogInfo(query, success, error) {
        requestFn({ method: 'get', url: '/data-retrieval/log-data-audit', query, success, error });
    },
    // 原数据检索：查询资产漏洞情况
    getVsVaResult(query, success, error) {
        requestFn({ method: 'get', url: '/data-retrieval/vs-va-result', query, success, error });
    },
    /* -------数据一览-------end */

    /* -------态势评估与预测-------start */
    // 查询被保护的数据库资产（按健康度排序）
    getDbProtectedAssets(query, success, error) {
        requestFn({ method: 'get', url: '/database-assets/protected-assets', query, success, error });
    },
    // 态势评估：获取总体安全态势趋势
    getGenralSituation(query, success, error) {
        requestFn({ method: 'get', url: '/situation-assessment/genral-situation', query, success, error });
    },
    // 态势评估：获取安全态势各个指标的数据
    getEveryTargetSituation(query, success, error) {
        requestFn({ method: 'get', url: '/situation-assessment/every-target-data', query, success, error });
    },
    // 态势评估：获取最近一个小时的评估数据
    getLastHourAssess(query, success, error) {
        requestFn({ method: 'get', url: '/situation-assessment/query-latest-hour-data', query, success, error });
    },
    // 态势预测：获取未来一小时的预测数据
    getNatureHourPredict(query, success, error) {
        requestFn({ method: 'get', url: '/situation-predict/nature-hour-data', query, success, error });
    },
    // 态势预测：获取总体安全态势预测数据
    getSafetyPredict(query, success, error) {
        requestFn({ method: 'get', url: '/situation-predict/safety-predict', query, success, error });
    },
    // 态势预测：获取数据库流量预测数据、获取用户请求数预测数据、获取敏感表访问量预测
    getSubTargetPredict(query, success, error) {
        requestFn({ method: 'get', url: '/situation-predict/flow-predict', query, success, error });
    },
    /* -------态势评估与预测-------end */


    /* -------数据资产-------start */
    // 数据资产管理：资产概览
    getAssetsOverview(query, success, error) {
        requestFn({ method: 'get', url: '/database-assets/view', query, success, error });
    },

    // 数据资产管理：资产管理-查询数据库资产
    getDatabaseAsset(query, success, error) {
        requestFn({ method: 'get', url: '/database-assets/database', query, success, error });
    },
    // 数据资产管理：资产管理-获取资产所有部门
    getAssetsDept(query, success, error) {
        requestFn({ method: 'get', url: '/database-assets/department', query, success, error });
    },

    // 数据资产管理：资产管理-获取所有资产类型
    getDatabaseTypeData(query, success, error) {
        requestFn({ method: 'get', url: '/database-assets/database-type', query, success, error });
    },

    // 数据资产管理：资产管理-获取Oracle数据库用户
    postOracleUserData(query, success, error) {
        requestFn({ method: 'post', url: '/database-assets/oracle-user', query, success, error });
    },

    // 数据资产管理：资产管理-测试连接
    postTestConn(query, success, error) {
        requestFn({ method: 'post', url: '/database-assets/test-conn', query, success, error });
    },

    // 数据资产管理：资产管理-获取模式名
    postSchemaData(query, success, error) {
        requestFn({ method: 'post', url: '/database-assets/schemas', query, success, error });
    },

    // 数据资产管理：资产管理-添加数据库资产
    postDatabaseAsset(query, success, error) {
        requestFn({ method: 'post', url: '/database-assets/database', query, success, error });
    },

    // 数据资产管理：资产管理-修改数据库资产
    putDatabaseAsset(query, success, error) {
        requestFn({ method: 'put', url: '/database-assets/database', query, success, error });
    },

    // 数据资产管理：资产管理-删除数据库资产
    deleteDatabaseAsset(query, success, error) {
        requestFn({ method: 'post', url: '/database-assets/delete/database', query, success, error });
    },

    // 数据资产管理：资产管理-查询指定数据库资产详情
    getDbAssetDetail(query, success, error) {
        requestFn({ method: 'get', url: '/database-assets/query-information', query, success, error });
    },

    // 数据资产管理：资产管理-查询树形图数据
    getTreeData(query, success, error) {
        requestFn({ method: 'get', url: '/database-assets/query-information-search', query, success, error });
    },

    // 数据资产管理：资产管理-批量修改资产部门
    putBatchDept(query, success, error) {
        requestFn({ method: 'put', url: '/database-assets/dept-selective', query, success, error });
    },

    // 数据资产管理：资产发现-添加扫描任务
    postAddScanTask(query, success, error) {
        requestFn({ method: 'post', url: '/database-discover/task', query, success, error });
    },

    // 数据资产管理：资产发现-删除扫描任务
    deleteScanTask(query, success, error) {
        requestFn({ method: 'post', url: '/database-discover/delete/task', query, success, error });
    },

    // 查询自动发现扫描任务
    getScanTaskDetail(query, success, error) {
        requestFn({ method: 'get', url: '/database-discover/task-info', query, success, error });
    },

    // 数据资产管理：资产发现-开始扫描自动发现任务
    putStartScan(query, success, error) {
        requestFn({ method: 'put', url: '/database-discover/task-discovery-start', query, success, error });
    },

    // 数据资产管理：资产发现-停止正在扫描的自动发现任务
    putStopScan(query, success, error) {
        requestFn({ method: 'put', url: '/database-discover/task-discovery-stop', query, success, error });
    },
    // 数据资产管理：资产发现-查询扫描任务结果
    getAutoDiscoverData(query, success, error) {
        requestFn({ method: 'get', url: '/database-discover/task', query, success, error });
    },
    // 数据资产管理：资产发现-将扫描任务结果添加至资产库
    postAddScanResToAssetLib(query, success, error) {
        requestFn({ method: 'post', url: '/database-discover/task-infos', query, success, error });
    },

    // 数据资产：敏感发现，获取任务表格数据
    getSensTasks(query, success, error) {
        requestFn({ method: 'get', url: '/sens-data-task/find-task', query, success, error });
    },
    // 数据资产：敏感发现，添加任务
    postSensTask(query, success, error) {
        requestFn({ method: 'post', url: '/sens-data-task/find-task', query, success, error });
    },
    // 数据资产：敏感发现，修改任务
    putSensTask(query, success, error) {
        requestFn({ method: 'put', url: '/sens-data-task/find-task', query, success, error });
    },
    // 数据资产：敏感发现，修改任务状态 开始/暂停
    putSensTaskStatus(query, success, error) {
        requestFn({ method: 'put', url: '/sens-data-task/find-task-status', query, success, error });
    },
    // 数据资产：敏感发现，删除任务
    deleteSensTask(query, success, error) {
        requestFn({ method: 'post', url: '/sens-data-task/delete/find-task', query, success, error });
    },
    // 数据资产：敏感发现，查询敏感类型自动发现支持的资产
    getDatabaseDz(query, success, error) {
        requestFn({ method: 'get', url: '/database-assets/database-dz', query, success, error });
    },
    // 数据资产：敏感发现，查询资产所有表信息
    getDatabaseTableInfo(query, success, error) {
        requestFn({ method: 'get', url: '/database-assets/database-tablename-info', query, success, error });
    },
    // 数据资产：敏感发现，获取某一任务详情
    getSensTaskDetail(query, success, error) {
        requestFn({ method: 'get', url: '/sens-data-task/find-info', query, success, error });
    },
    // 数据资产：敏感发现，获取任务结果
    getSensTaskResult(query, success, error) {
        requestFn({ method: 'get', url: '/sens-data-task/find-details', query, success, error });
    },

    // 数据资产：敏感类型,获取数据
    getSensType(query, success) {
        requestFn({ method: 'get', url: '/sensitive/sens-type', query, success });
    },

    // 数据资产：敏感类型,添加数据
    postSensType(query, success, error) {
        requestFn({ method: 'post', url: '/sensitive/sens-type', query, success, error });
    },

    // 数据资产：敏感类型,修改数据
    putSensType(query, success, error) {
        requestFn({ method: 'put', url: '/sensitive/sens-type', query, success, error });
    },
    // 数据资产：敏感类型,删除数据
    deleteSensType(query, success, error) {
        requestFn({ method: 'post', url: '/sensitive/delete/sens-type', query, success, error });
    },
    // 数据资产：敏感类型,校验
    testSensType(query, success, error) {
        requestFn({ method: 'post', url: '/sensitive/test-sens-type', query, success, error });
    },
    // 数据资产：敏感类型,详情数据
    getSensDetail(query, success, error) {
        requestFn({ method: 'get', url: '/sensitive/sens-type-detail', query, success, error });
    },

    // 数据资产：数据字典,查询
    getDictionary(query, success) {
        requestFn({ method: 'get', url: '/dictionary/data-dictionary', query, success });
    },
    postDictionary(query, success, error) {
        requestFn({ method: 'post', url: '/dictionary/data-dictionary', query, success, error });
    },

    // 数据资产：数据字典,修改
    putDictionary(query, success, error) {
        requestFn({ method: 'put', url: '/dictionary/data-dictionary', query, success, error });
    },
    // 数据资产：数据字典,删除
    deleteDictionary(query, success, error) {
        requestFn({ method: 'post', url: '/dictionary/delete/data-dictionary', query, success, error });
    },
    // 数据资产：数据字典,查询(详情)
    getDicDetail(query, success) {
        requestFn({ method: 'get', url: '/dictionary/data-dictionary-detail', query, success });
    },
    // 数据资产：数据字典,添加(详情)
    postDicDetail(query, success) {
        requestFn({ method: 'post', url: '/dictionary/data-dictionary-detail', query, success });
    },
    // 数据资产：数据字典,修改详情
    putDicDetail(query, success, error) {
        requestFn({ method: 'put', url: '/dictionary/data-dictionary-detail', query, success, error });
    },
    // 数据资产：数据字典,删除(详情)
    deleteDicDetail(query, success) {
        requestFn({ method: 'post', url: '/dictionary/delete/data-dictionary-detail', query, success });
    },
    /* -------数据资产-------end */

    /* -------作战能力单元-------start */
    // 作战能力单元，获取设备列表
    getUnitData(query, success) {
        requestFn({ method: 'get', url: '/safety-devices/devices', query, success });
    },
    // 作战能力单元，获取设备列表
    getPerformance(query, success) {
        requestFn({ method: 'get', url: '/safety-devices/devices-function', query, success });
    },
    // 作战能力单元，添加设备
    postUnitData(query, success, error) {
        requestFn({ method: 'post', url: '/safety-devices/devices', query, success, error });
    },
    // 作战能力单元，测试URL
    testUrl(query, success, error) {
        requestFn({ method: 'post', url: '/safety-devices/test-devices', query, success, error });
    },
    // 作战能力单元，测试URL
    collectionTest(query, success, error) {
        requestFn({ method: 'post', url: '/internet-server/dev-snmp-test', query, success, error });
    },
    // 作战能力单元，修改设备
    putUnitData(query, success, error) {
        requestFn({ method: 'put', url: '/safety-devices/devices', query, success, error });
    },
    // 作战能力单元，删除设备
    deleteUnitData(query, success) {
        requestFn({ method: 'post', url: '/safety-devices/delete/devices', query, success });
    },
    // 作战能力单元，改变开关状态
    postSwitchState(query, success, error) {
        requestFn({ method: 'post', url: '/safety-devices/switch-devices', query, success, error });
    },
    // 作战能力单元，获取设备详情
    getUnitDetail(query, success) {
        requestFn({ method: 'get', url: '/safety-devices/query-information', query, success });
    },
    // 作战能力单元，获取拓展配置
    getExtendConfig(query, success) {
        requestFn({ method: 'get', url: '/safety-devices/extend-config', query, success });
    },
    // 作战能力单元，添加拓展配置
    postExtendConfig(query, success) {
        requestFn({ method: 'post', url: '/safety-devices/extend-config', query, success });
    },
    // 作战能力单元，获取设备类型列表
    getDevType(success) {
        requestFn({ method: 'get', url: '/safety-devices/type', success });
    },

    /* -------作战能力单元-------end */


    /* -------组织架构-------start */
    // 组织架构：获取组织架构数据
    getOrgStructureInfo(query, success, error) {
        requestFn({ method: 'get', url: '/orgnization-structure/structure-info', query, success, error });
    },
    // 组织架构：获取组织架构的一级部门数据
    getOrgParentInfo(query, success, error) {
        requestFn({ method: 'get', url: '/orgnization-structure/query-parent-info', query, success, error });
    },
    // 组织架构：修改公司名称
    putOrgCompanyName(query, success, error) {
        requestFn({ method: 'put', url: '/orgnization-structure/company-name', query, success, error });
    },
    // 组织架构：添加部门
    postOrgStructure(query, success, error) {
        requestFn({ method: 'post', url: '/orgnization-structure/structure-info', query, success, error });
    },
    // 组织架构：修改部门
    putOrgStructure(query, success, error) {
        requestFn({ method: 'put', url: '/orgnization-structure/structure-info', query, success, error });
    },
    // 组织架构：删除部门
    deleteOrgStructure(id, success, error) {
        requestFn({ method: 'delete', url: '/orgnization-structure/structure-info/' + id, success, error });
    },
    // 组织架构：获取所有组织架构，相关引用模块下拉框内容
    getOrgStructureOption(query, success, error) {
        requestFn({ method: 'get', url: '/orgnization-structure/structure-all', query, success, error });
    },
    /* -------组织架构-------end */


    /* -------情景模式-------start */
    // 情景模式：获取情景模式数据
    getSceneModes(query, success, error) {
        requestFn({ method: 'get', url: '/analysis-model/model-config', query, success, error });
    },
    // 情景模式：添加情景配置
    addSceneMode(query, success, error) {
        requestFn({ method: 'post', url: '/analysis-model/model-config', query, success, error });
    },
    // 情景模式：修改情景配置
    putSceneMode(query, success, error) {
        requestFn({ method: 'put', url: '/analysis-model/model-config', query, success, error });
    },
    // 情景模式：修改情景配置状态
    putSceneModeStatus(query, success, error) {
        requestFn({ method: 'put', url: '/analysis-model/model-config-status', query, success, error });
    },
    // 情景模式：删除情景模式数据
    deleteSceneModes(query, success, error) {
        requestFn({ method: 'post', url: '/analysis-model/delete/model-config', query, success, error });
    },
    // 情景模式：获取全部数据库资产
    getAllDbAssets(query, success, error) {
        requestFn({ method: 'get', url: '/database-assets/db-names', query, success, error });
    },
    /* -------情景模式-------end */


    /* -------系统安全-------start */
    // 系统安全：获取系统安全配置
    getSysSecConfig(query, success, error) {
        requestFn({ method: 'get', url: '/system-safety/system-security-config', query, success, error });
    },
    // 系统安全：保存系统安全配置
    postSysSecConfig(query, success, error) {
        requestFn({ method: 'post', url: '/system-safety/system-security-config', query, success, error });
    },
    // 系统安全：校验本地IP是否在黑名单中
    postCheckIpConfig(query, success, error) {
        requestFn({ method: 'post', url: '/system-safety/check-ip-config', query, success, error });
    },
    // 系统安全：保存黑白名单配置
    postLoginIpConfig(query, success, error) {
        requestFn({ method: 'post', url: '/system-safety/login-ip-config', query, success, error });
    },
    /* -------系统安全-------end */


    /* -------通信配置-------start */
    // 通信配置：获取邮件服务器配置
    getMailServerConfig(query, success, error) {
        requestFn({ method: 'get', url: '/internet-server/mail-server-config', query, success, error });
    },
    // 通信配置：保存邮件服务器配置
    postMailServerConfig(query, success, error) {
        requestFn({ method: 'post', url: '/internet-server/mail-server-config', query, success, error });
    },
    // 通信配置：修改邮件服务器状态
    putMailServerStatus(query, success, error) {
        requestFn({ method: 'put', url: '/internet-server/mail-server-status', query, success, error });
    },
    // 通信配置：测试邮件服务器
    postMailServerTest(query, success, error) {
        requestFn({ method: 'post', url: '/internet-server/mail-config-test', query, success, error });
    },
    // 通信配置：删除备用邮件服务器
    deleteSpareMailServer(id, success, error) {
        requestFn({ method: 'delete', url: '/internet-server/mail-server-config/' + id, success, error });
    },
    // 通信配置：获取 短信服务器 配置
    getMsgServer(query, success, error) {
        requestFn({ method: 'get', url: '/internet-server/msg-platform-config', query, success, error });
    },
    // 通信配置：添加 短信服务器 配置
    postMsgServer(query, success, error) {
        requestFn({ method: 'post', url: '/internet-server/msg-platform-config', query, success, error });
    },
    // 通信配置：修改 短信服务器 配置
    putMsgServer(query, success, error) {
        requestFn({ method: 'put', url: '/internet-server/msg-platform-config', query, success, error });
    },
    // 通信配置：删除 短信服务器 配置
    deleteMsgServer(id, success, error) {
        requestFn({ method: 'delete', url: '/internet-server/msg-platform-config/' + id, success, error });
    },
    // 通信配置：获取 FTP 配置
    getFtpServer(query, success, error) {
        requestFn({ method: 'get', url: '/internet-server/ftp-server-config', query, success, error });
    },
    // 通信配置：添加 FTP 配置
    postFtpServer(query, success, error) {
        requestFn({ method: 'post', url: '/internet-server/ftp-server-config', query, success, error });
    },
    // 通信配置：修改 FTP 配置
    putFtpServer(query, success, error) {
        requestFn({ method: 'put', url: '/internet-server/ftp-server-config', query, success, error });
    },
    // 通信配置：删除 FTP 配置
    deleteFtpServer(id, success, error) {
        requestFn({ method: 'delete', url: '/internet-server/ftp-server-config/' + id, success, error });
    },
    // 通信配置：测试 FTP 配置
    postFtpTest(query, success, error) {
        requestFn({ method: 'post', url: '/internet-server/ftp-config-test', query, success, error });
    },
    // 通信配置：获取 SNMP 配置
    getSnmpServer(query, success, error) {
        requestFn({ method: 'get', url: '/internet-server/snmp-server-config', query, success, error });
    },
    // 通信配置：添加 SNMP 配置
    postSnmpServer(query, success, error) {
        requestFn({ method: 'post', url: '/internet-server/snmp-server-config', query, success, error });
    },
    // 通信配置：修改 SNMP 配置
    putSnmpServer(query, success, error) {
        requestFn({ method: 'put', url: '/internet-server/snmp-server-config', query, success, error });
    },
    // 通信配置：删除 SNMP 配置
    deleteSnmpServer(id, success, error) {
        requestFn({ method: 'delete', url: '/internet-server/snmp-server-config/' + id, success, error });
    },
    // 通信配置：测试 SNMP 配置
    postSnmpTest(query, success, error) {
        requestFn({ method: 'post', url: '/internet-server/snmp-config-test', query, success, error });
    },
    // 通信配置：获取 Syslog 配置
    getSyslogServer(query, success, error) {
        requestFn({ method: 'get', url: '/internet-server/syslog-server-config', query, success, error });
    },
    // 通信配置：添加 Syslog 配置
    postSyslogServer(query, success, error) {
        requestFn({ method: 'post', url: '/internet-server/syslog-server-config', query, success, error });
    },
    // 通信配置：修改 Syslog 配置
    putSyslogServer(query, success, error) {
        requestFn({ method: 'put', url: '/internet-server/syslog-server-config', query, success, error });
    },
    // 通信配置：删除 Syslog 配置
    deleteSyslogServer(id, success, error) {
        requestFn({ method: 'delete', url: '/internet-server/syslog-server-config/' + id, success, error });
    },
    // 通信配置：测试 Syslog 配置
    postSyslogTest(query, success, error) {
        requestFn({ method: 'post', url: '/internet-server/syslog-config-test', query, success, error });
    },

    /* -------通信配置-------end */


    /* -------日志管理-------start */
    // 系统日志：查询系统日志
    getSystemLog(query, success, error) {
        requestFn({ method: 'get', url: '/log/system-log', query, success, error });
    },
    // 系统日志：导出系统日志，下载日志文件
    getSystemLogFile(query, success, error) {
        let userOption = {
            responseType: 'blob'
        };
        requestFn({ method: 'get', url: '/log/export-system-log', query, success, error, userOption });
    },
    // 操作日志，查询操作日志
    getOperLog(query, success, error) {
        requestFn({ method: 'get', url: '/log/operation-log', query, success, error });
    },
    // 操作日志，查询用户名
    getUserName(success, error) {
        requestFn({ method: 'get', url: '/log/user-name-list', success, error });
    },
    // 操作日志，查询登录IP列表
    getLoginIp(success, error) {
        requestFn({ method: 'get', url: '/log/login-ip-list', success, error });
    },
    // 操作日志，查询模块列表
    getMoudle(success, error) {
        requestFn({ method: 'get', url: '/log/module-list', success, error });
    },
    // 操作日志：导出操作日志，下载日志文件
    getOperLogFile(query, success, error) {
        let userOption = {
            responseType: 'blob'
        };
        requestFn({ method: 'get', url: 'log/export-operation-log', query, success, error, userOption });
    },
    /* -------日志管理-------end */

    /* -------安全模型-------start */
    // 安全模型--安全规则配置
    getRuleConfig(query, success, error) {
        requestFn({ method: 'get', url: '/security-rule/rule-config', query, success, error });
    },
    // 安全模型--安全规则配置
    postRuleConfig(query, success, error) {
        requestFn({ method: 'post', url: '/security-rule/rule-config', query, success, error });
    },
    // 配置管理--责任人：删除责任人
    deleteDutyPerson(query, success, error) {
        requestFn({ method: 'post', url: '/manager-config/delete/manager', query, success, error });
    },
    // 配置管理--责任人：修改责任人
    putDutyPerson(query, success, error) {
        requestFn({ method: 'put', url: '/manager-config/manager', query, success, error });
    },
    /* -------安全模型-------end */

    /* -------责任人-------start */
    // 配置管理--责任人：获取所有责任人数据
    getDutyPersonData(query, success, error) {
        requestFn({ method: 'get', url: '/manager-config/manager', query, success, error });
    },
    // 配置管理--责任人：添加责任人
    postDutyPerson(query, success, error) {
        requestFn({ method: 'post', url: '/manager-config/manager', query, success, error });
    },
    // 配置管理--责任人：删除责任人
    deleteDutyPerson(query, success, error) {
        requestFn({ method: 'post', url: '/manager-config/delete/manager', query, success, error });
    },
    // 配置管理--责任人：修改责任人
    putDutyPerson(query, success, error) {
        requestFn({ method: 'put', url: '/manager-config/manager', query, success, error });
    },
    /* -------责任人-------end */

    /* -------系统时间-------start */
    // 系统管理-系统时间：获取系统时间
    getSysTime(query, success, error) {
        requestFn({ method: 'get', url: '/system-time/time', query, success, error });
    },
    // 系统管理-系统时间：保存NTP配置
    postNTPConfig(query, success, error) {
        requestFn({ method: 'post', url: '/system-time/ntp-configure', query, success, error });
    },
    // 系统管理-系统时间：获取NTP配置
    getNTPConfig(query, success, error) {
        requestFn({ method: 'get', url: '/system-time/ntp-configure', query, success, error });
    },
    // 系统管理-系统时间：获取NTP服务时间
    getNTPTime(query, success, error) {
        requestFn({ method: 'get', url: '/system-time/ntp-time', query, success, error });
    },
    // 系统管理-系统时间：修改系统时间
    putSysTime(query, success, error) {
        requestFn({ method: 'put', url: '/system-time/time', query, success, error });
    },
    // 系统管理-系统时间：修改自动同步开关
    putNTPAutoSync(query, success, error) {
        requestFn({ method: 'put', url: '/system-time/ntp-autosyn', query, success, error });
    },
    /* -------系统时间-------end */

    /* -------系统告警-------start */
    // 系统管理-系统告警：获取系统时间
    getSysAlert(query, success, error) {
        requestFn({ method: 'get', url: '/system-alarm/alarm-config', query, success, error });
    },
    // 系统管理-系统告警：修改系统时间
    putSysAlert(query, success, error) {
        requestFn({ method: 'put', url: '/system-alarm/alarm-config', query, success, error });
    },
    getReceiverInfo(query, success, error) {
        requestFn({ method: 'get', url: '/system-alarm/check-alarm-receiver', query, success, error });
    },
    /* -------系统时间-------end */

    /* ------证书------start */
    // 软件授权：查询证书信息
    getAuthorizationStatus(success, error) {
        requestFn({ method: 'get', url: '/license/lic', success, error });
    },
    // 软件授权：证书校验
    postAuthorizationStatus(success, error) {
        requestFn({ method: 'post', url: '/license/authorization', success, error });
    },
    // 软件授权：下载注册信息文件
    getRegistInfor() {
        let userOption = {
            responseType: 'blob'
        };
        requestFn({ method: 'get', url: '/license/lic/download', userOption });
    },
    /* ------证书------end */

    /* ------用户管理------start */
    // 获取所有用户信息
    getAllUserInfo(query, success, error) {
        requestFn({ method: 'get', url: '/user/all-user-info', query, success, error });
    },
    // 获取用户详情信息
    getUserInfo(query, success, error) {
        requestFn({ method: 'get', url: '/user/user-info', query, success, error });
    },
    // 通过token信息查看用户信息与权限
    getUserByToken(success, error) {
        requestFn({ method: 'get', url: '/user/user-info-by-token', success, error });
    },
    // 添加用户
    postUserInfo(query, success, error) {
        requestFn({ method: 'post', url: '/user/user-info', query, success, error });
    },
    // 修改用户信息
    putUserInfo(query, success, error) {
        requestFn({ method: 'put', url: '/user/user-info', query, success, error });
    },
    // 删除用户
    deleteUserInfo(query, success, error) {
        requestFn({ method: 'post', url: '/user/delete/user-info', query, success, error });
    },
    // 修改用户锁定状态
    putLockState(query, success, error) {
        requestFn({ method: 'put', url: '/user/user-lock-state', query, success, error });
    },
    // 重置密码
    postPassword(query, success, error) {
        requestFn({ method: 'get', url: '/user/password', query, success, error });
    },
    // 修改密码
    putPassword(query, success, error) {
        requestFn({ method: 'put', url: '/user/password', query, success, error });
    },
    // 系统锁屏-解锁
    postSysLock(query, success, error) {
        requestFn({ method: 'post', url: '/login/system-lock-screen', query, success, error });
    },
    /* ------用户管理------end */
    /* -------------告警策略----------start */
    // 规则平台-告警-获取告警策略
    getAlarmStrategy(query, success) {
        requestFn({ method: 'get', url: '/alarm-strategy/conf', query, success });
    },
    // 规则平台-告警-获取告警策略被引用信息--暂时还没有写好引用，注释
    // getCitationStrategy(query, success) {
    //     requestFn({ method: 'get', url: '/alarm/alarmStrategy/citationStrategy', query, success });
    // },
    // 规则平台-告警策略-添加策略
    postAlarmStrategy(query, success) {
        requestFn({ method: 'post', url: '/alarm-strategy/conf', query, success });
    },
    // 规则平台-告警策略-修改策略
    putAlarmStrategy: function (query, success) {
        requestFn({ method: 'put', url: '/alarm-strategy/conf', query, success });
    },
    // 规则平台-告警策略-删除策略
    deleteAlarmStrategy: function (query, success) {
        requestFn({ method: 'post', url: '/alarm-strategy/delete/conf', query, success });
    },
    // 规则平台-告警-检查告警方式
    getCheckMode: function (query, success, error) {
        requestFn({ method: 'get', url: '/alarm-strategy/test', query, success, error });
    },
    // 规则平台-告警-检查接收人
    getReciver: function (success) {
        requestFn({ method: 'get', url: '/alarm-strategy/get-reciver', success });
    },
    /* -------------告警策略----------end */
};
