const moduleList = {
    sysadmin: [
        // 部署管理
        {
            name: 'deploy-manage',
            title: 'deployManage'
        },
        // 系统管理
        {
            name: 'sys-manage',
            title: 'sysManage',
            children: [
                {
                    name: 'system-log',
                    title: 'systemLog'
                },
                {
                    name: 'sys-alert',
                    title: 'sysAlert'
                },
                {
                    name: 'sys-upgrade',
                    title: 'sysUpgrade'
                },
                {
                    name: 'sys-security',
                    title: 'sysSecurity'
                },
                {
                    name: 'sys-diagnosis',
                    title: 'sysDiagnosis'
                },
                {
                    name: 'internet-server',
                    title: 'internetServer'
                },
                {
                    name: 'sys-time',
                    title: 'sysTime'
                },
            ]
        },
        // 设备管理
        {
            name: 'device-manage',
            title: 'deviceManage',
        },
        // 数据维护
        {
            name: 'data-maintain',
            title: 'dataMaintain',
        },
        // 许可证
        {
            name: 'license',
            title: 'license',
        },
    ],
    secadmin: [
        // 态势概览
        {
            name: 'situation-overview',
            title: 'situationOverview',
        },
        // 治理工作台
        {
            name: 'govern-platform',
            title: 'governPlatform',
            children: [
                {
                    name: 'retrieve-assets',
                    title: 'retrieveAssets'
                },
                {
                    name: 'data-browse',
                    title: 'dataBrowse'
                },
                {
                    name: 'situation-predict',
                    title: 'situationPredict'
                },
                {
                    name: 'data-flow',
                    title: 'dataFlow'
                },
                {
                    name: 'data-assets',
                    title: 'dataAssets',
                },
                {
                    name: 'topology-manage',
                    title: 'topologyManage',
                },
            ]
        },
        // 风险管理
        {
            name: 'risk-manage',
            title: 'riskManage',
            children: [
                {
                    name: 'risk-overview',
                    title: 'riskOverview'
                },
                {
                    name: 'risk-treatment',
                    title: 'riskTreatment'
                }
            ]
        },
        // 报表管理
        {
            name: 'report-manage',
            title: 'reportManage',
            children: [
                {
                    name: 'attribute-report',
                    title: 'attributeReport'
                },
                {
                    name: 'grade-protect-report',
                    title: 'gradeProtectReport'
                },
                {
                    name: 'workbench',
                    title: 'workbench'
                }
            ]
        },
        // 能力单元管理
        {
            name: 'ability-unit',
            title: 'abilityUnit',
        },
        // 配置管理
        {
            name: 'config-manage',
            title: 'configManage',
            children: [
                {
                    name: 'rule-config',
                    title: 'ruleConfig',
                },
                {
                    name: 'parsing-rule',
                    title: 'parsingRule',
                },
                {
                    name: 'analysis-task',
                    title: 'analysisTask',
                },
                {
                    name: 'linkage',
                    title: 'linkage',
                },
                {
                    name: 'threat',
                    title: 'threat',
                },
                {
                    name: 'alarm-strategy',
                    title: 'alarmStrategy'
                },
                {
                    name: 'org-structure',
                    title: 'orgStructure'
                },
                {
                    name: 'duty-person',
                    title: 'dutyPerson'
                }
            ]
        },
    ],
    auditadmin: [
        {
            name: 'operation-log',
            title: 'operationLog'
        }
    ]
};

export default moduleList;
