<template>
    <div class="content-wrap">
        <div class="content-fill">
            <header class="operate-wrap">
                <!--添加-->
                <button class="primary-btn add-btn" @click="addModifyRule('add')">
                    <i class="add-i"></i>{{$t('Common.button.add')}}
                </button>
                <!--删除-->
                <button class="primary-btn delete-btn" @click="confirmDel('')">
                    <i class="delete-i"></i>{{$t('Common.button.delete')}}
                </button>
                <!--搜索-->
                <input class="input-inner" v-model.trim="searchData" @keyup.enter="searchDatabase"
                    maxlength="32" :placeholder="$t('AssetsManage.searchPlaceholder')">
                <button class="primary-btn" @click="searchDatabase">{{$t('Common.button.search')}}</button>
            </header>
            <main class="sec-rule-wrap">内容</main>
        </div>
    </div>
</template>

<script>
export default {
    name: 'rule'
};
</script>

<style scoped lang="scss">
.content-wrap {
    padding: 15px;
}
</style>