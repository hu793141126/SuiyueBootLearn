<template>
    <div>
        <header class="operate-wrap"></header>
        <main class="content-wrap"></main>
    </div>
</template>

<script>
export default {
    name: 'rule'
};
</script>

<style scoped>

</style>