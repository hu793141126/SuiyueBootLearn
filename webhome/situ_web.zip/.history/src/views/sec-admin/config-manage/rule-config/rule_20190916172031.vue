<template>
    <div>
        规则
    </div>
</template>

<script>
export default {
    name: 'rule'
};
</script>

<style scoped>

</style>