<template>
    <div>
        <header class="operate-wrap">操作栏</header>
        <main class="content-wrap"></main>
    </div>
</template>

<script>
export default {
    name: 'rule'
};
</script>

<style scoped>

</style>