<template>
    <div>
        header.operate-wrap+main.
    </div>
</template>

<script>
export default {
    name: 'rule'
};
</script>

<style scoped>

</style>