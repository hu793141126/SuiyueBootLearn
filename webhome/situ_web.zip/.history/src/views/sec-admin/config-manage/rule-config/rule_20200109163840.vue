<template>
    <div class="content-wrap">
        <div class="content-fill">
            <header class="operate-wrap">操作栏</header>
            <main class="">内容</main>
        </div>
    </div>
</template>

<script>
export default {
    name: 'rule'
};
</script>

<style scoped>

</style>