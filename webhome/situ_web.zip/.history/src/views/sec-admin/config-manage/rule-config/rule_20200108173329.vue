<template>
    <div>
        <header></header>
    </div>
</template>

<script>
export default {
    name: 'rule'
};
</script>

<style scoped>

</style>