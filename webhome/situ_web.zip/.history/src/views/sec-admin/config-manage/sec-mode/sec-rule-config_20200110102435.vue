<template>
    <div class="content-wrap">
        <div class="content-fill">
            <header class="operate-wrap">
                <!--添加-->
                <button class="primary-btn add-btn" @click="addModifyRule('add')">
                    <i class="add-i"></i>{{$t('Common.button.add')}}
                </button>
                <!--删除-->
                <button class="primary-btn delete-btn" @click="confirmDel('')">
                    <i class="delete-i"></i>{{$t('Common.button.delete')}}
                </button>
                <!--搜索-->
                <input class="input-inner" v-model.trim="searchData" @keyup.enter="searchRule"
                    maxlength="32" :placeholder="$t('secMode.secRuleConfig.searchInput')">
                <button class="primary-btn" @click="searchRule">{{$t('Common.button.search')}}</button>
            </header>
            <main class="sec-rule-wrap">
                <!-- <ak-table>
                </ak-table>
                <ak-paging>
                </ak-paging> -->
            </main>
        </div>
    </div>
</template>

<script>
let vm = '';
export default {
    name: 'sec-rule-config',
    data() {
        return {
            // 安全规则配置的所有数据
            ruleConfig: {
                list: [],
                total: 10,
                page: 1,
                size: 10,
            },
            searchData: '', // 搜索框的数据
            
        }
    },
    mounted () {
        vm = this;
        vm.ready();
    },
    methods: {
        ready() {
        }
    },
};
</script>

<style scoped lang="scss">
.content-wrap {
    padding: 15px;
}
.content-fill {
    border: 1px solid rgba(173,181,199,1);
    box-shadow: 0 3px 10px rgba(60,67,77,0.16);
}
</style>