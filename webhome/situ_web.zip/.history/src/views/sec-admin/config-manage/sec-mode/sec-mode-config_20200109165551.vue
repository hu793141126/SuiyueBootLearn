<template>
    <div>
        规则组
    </div>
</template>

<script>
export default {
    name: 'rule-group'
};
</script>

<style scoped>

</style>