<template>
    <div class="content-wrap">
       
       
    </div>
</template>

<script>
export default {
    name: 'sec-rule-config'
};
</script>

<style scoped lang="scss">
.content-wrap {
    padding: 15px;
}
</style>