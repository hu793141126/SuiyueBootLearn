<template>
    <div style="height: 100%;">
        <!--tab栏切换-->
        <el-tabs v-model="activeName" :before-leave="changeTab">
            <el-tab-pane :label="$t('ModuleList.secRuleConfig')" name="secRuleConfig">
            </el-tab-pane>
            <el-tab-pane :label="$t('ModuleList.secModeConfig')" name="secModeConfig">
            </el-tab-pane>
        </el-tabs>

        <!--各个子组件-->
        <sec-rule v-if="activeName === 'secRuleConfig'"></sec-rule>
        <sec-mode v-if="activeName === 'secModeConfig'"></sec-mode>
    </div>
</template>

<script>
import secRuleConfig from './sec-rule-config';
import secModeConfig from './sec-mode-config';

export default {
    name: 'sec-mode',
    data() {
        return {
            activeName: this.$route.query.active || '',
        };
    },
    components: {
        secRule,
        secMode,
    },
    methods: {
        // 点击切换tab标签页，或者改变了 activeName ，就会触发
        changeTab(activeName, oldActiveName) {
            debugger
            this.$router.push({
                name: this.$route.name,
                query: { active: activeName }
            });
        },
    }
};
</script>

<style scoped>

</style>