<template>
    <div>
        规则组
    </div>
</template>

<script>
export default {
    name: 'sec-mode-config'
};
</script>

<style scoped>

</style>