<template>
    <div>
        安全模型配置
    </div>
</template>

<script>
export default {
    name: 'sec-mode-config'
};
</script>

<style scoped>

</style>