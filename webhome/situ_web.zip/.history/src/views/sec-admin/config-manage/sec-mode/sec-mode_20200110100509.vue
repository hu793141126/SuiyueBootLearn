<template>
    <div style="height: 100%;">
        <!--tab栏切换-->
        <el-tabs v-model="activeName" :before-leave="changeTab">
            <el-tab-pane :label="$t('ModuleList.secRuleConfig')" name="secRuleConfig">
            </el-tab-pane>
            <el-tab-pane :label="$t('moduleList.secModeConfig')" name="secModeConfig">
            </el-tab-pane>
        </el-tabs>

        <!--各个子组件-->
        <sec-rule-config v-if="activeName === 'secRuleConfig'"></sec-rule-config>
        <sec-mode-config v-if="activeName === 'secModeConfig'"></sec-mode-config>
    </div>
</template>

<script>
import secRuleConfig from './sec-rule-config';
import secModeConfig from './sec-mode-config';

export default {
    name: 'sec-mode',
    data() {
        return {
            activeName: this.$route.query.active || '',
        };
    },
    components: {
        secRuleConfig,
        secModeConfig,
    },
    methods: {
        // 点击切换tab标签页，或者改变了 activeName ，就会触发
        changeTab(activeName, oldActiveName) {
            this.$router.push({
                name: this.$route.name,
                query: { active: activeName }
            });
        },
    }
};
</script>

<style scoped>

</style>