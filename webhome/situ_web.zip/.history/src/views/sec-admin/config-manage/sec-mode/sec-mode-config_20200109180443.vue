<template>
    <div>
        规则组
    </div>
</template>

<script>
export default {
    name: 'sec-'
};
</script>

<style scoped>

</style>