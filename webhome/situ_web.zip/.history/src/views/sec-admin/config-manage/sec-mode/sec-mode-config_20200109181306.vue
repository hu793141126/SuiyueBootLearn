<template>
    <div>
        安全
    </div>
</template>

<script>
export default {
    name: 'sec-mode-config'
};
</script>

<style scoped>

</style>