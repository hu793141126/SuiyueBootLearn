<template>
    <div style="height: 100%;">
        <!--tab栏切换-->
        <el-tabs v-model="activeName" :before-leave="changeTab">
            <el-tab-pane :label="$t('ModuleList.rule')" name="rule">
            </el-tab-pane>
            <el-tab-pane :label="$t('ModuleList.ruleGroup')" name="ruleGroup">
            </el-tab-pane>
        </el-tabs>

        <!--各个子组件-->
        <rule v-if="activeName === 'rule'"></rule>
        <rule-group v-if="activeName === 'ruleGroup'"></rule-group>
        <scene-mode v-if="activeName === 'sceneMode'"></scene-mode>
    </div>
</template>

<script>
import rule from './rule-config/rule';
import ruleGroup from './rule-config/rule-group';
import sceneMode from './rule-config/scene-mode';

export default {
    name: 'data-assets',
    data() {
        return {
            activeName: this.$route.query.active || '',
        };
    },
    components: {
        rule,
        ruleGroup,
        sceneMode,
    },
    methods: {
        // 点击切换tab标签页，或者改变了 activeName ，就会触发
        changeTab(activeName, oldActiveName) {
            this.$router.push({
                name: this.$route.name,
                query: { active: activeName }
            });
        },
    }
};
</script>

<style scoped>

</style>